<html>
<head><title>PHP and MySQL</title></head>
<body>
<h1>Test of PHP</h1>
<?php
 include "includepassword.php";
 mysqli_select_db($link,"donor2");
$idno=$_POST["inidno"];
$sql = "DELETE FROM donor WHERE idno = '$idno'";
$result= mysqli_query($link,$sql) or die(mysqli_error($link));
$showresult = mysqli_query($link,"SELECT * from donor")
    or die("Invalid query: " . mysqli_error($link));
while ($row = mysqli_fetch_array($showresult))
   {
    echo ("<br> ID = ". $row["idno"] . "<br> NAME =  " . $row["name"] . "<br>");
    echo("STREET = " . $row["stadr"] . "<br> CITY = " . $row["city"] . "<br>");
    echo("STATE = " . $row["state"] . "<br> YEAR GOAL = " . $row["yrgoal"] . "<br>");
   }
?>
</body>
</html>