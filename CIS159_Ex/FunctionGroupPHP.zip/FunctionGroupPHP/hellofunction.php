<html>
<head><title>Function</title></head>
<body>
<h2>Simple Function</h2>
<p>This is going to illustrate the use of a simple function to say hello world 
multiple times.</p>
<?php
sayhello();
sayhello();
sayhello();
function sayhello()
     {
     print "Hello World!  ";
      } // end sayhello
?>
</body>
</html>
