<html>
<head><title>Testing connection</title></head>
<body>
<h1>Testing connection</h1>
<?php
include "linkpass.php";
mysqli_select_db($link,"invfirst");
$result = mysqli_query($link,"SELECT itemno, itemname from itemfirst where itemno = '11111'");
$row = mysqli_fetch_row($result);
if ($row[0]=="")
    {
      print ("<br> What? ");
      exit;
    }
echo "<br>";
echo $row[0];
echo "<br>";
echo $row[1];
?>
</body>
</html>
