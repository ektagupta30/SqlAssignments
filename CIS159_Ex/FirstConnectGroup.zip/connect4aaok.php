<?php
//$link = mysql_connect("localhost", "username", "password")
//or die("Could not connect: " . mysql_error());
include "linkpass.php";
mysqli_select_db($link,"invfirst");
$result = mysqli_query($link,"SELECT * from itemfirst")
or die("<br>Invalid query: " . mysqli_error($link));
while ( $row = mysqli_fetch_row($result))
{
echo ("<p>" . $row[0] . $row[1] . $row[5] . "</p>");
}
?>