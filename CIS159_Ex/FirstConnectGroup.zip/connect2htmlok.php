<html>
<head><title>Testing connection</title></head>
<body>
<h1>Testing connection</h1>
<?php
include "linkpass.php";
mysqli_select_db($link,"invfirst");
$result = mysqli_query($link,"SELECT * from itemfirst")
or die("<br>Invalid query: " . mysqli_error($link));
echo "<br>linked to database";
?>
</body>
</html>

