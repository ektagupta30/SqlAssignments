<?php
session_start();
session_unset();
// removes session variables but not session
?>