<?php
session_start();
$_SESSION['seats'] = '24';
unset($_SESSION['crscd']);
?>