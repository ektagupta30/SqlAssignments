<?php
$aCustomer="Linda French";
setcookie("customer",$aCustomer,time()+3600);
?>
<html>
<head><title>Setting a cookie</title></head>
<body>
<h1>Setting a cookie to expire in one hour</h1>
</body>
</html>

