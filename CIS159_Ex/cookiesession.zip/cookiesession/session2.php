<?php 
session_start(); 
echo "The color value is ".$_SESSION['color']; 
echo "<br />";
echo "The thing value is ".$_SESSION['thing']; 
?> 