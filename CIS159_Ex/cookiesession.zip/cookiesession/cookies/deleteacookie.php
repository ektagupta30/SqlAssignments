<?php
setcookie("student","",time()-60);
echo "Set the time on the student cookie to delete";
?>