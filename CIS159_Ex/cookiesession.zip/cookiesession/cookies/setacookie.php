<?php
setcookie("student","John Doe", time()+60);
echo "A cookie named student has been set to John Doe and will last one minute";
?>