<?php
session_start();
$userpswd = array('123/a4b','124/bz4','125/7yH');
$_SESSION['crscd']='CIS159';
$_SESSION['seats']=30;
$_SESSION['login']=$userpswd;
?>