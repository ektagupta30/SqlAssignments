<html>
<head><title>Arrays</title></head>
<body>
<h2>Department Array</h2>
<?php
$deptName[] = "Womens";
$deptName[] = "Mens";
$deptName[] = "Girls";
$deptName[] = "Boys";
print_r($deptName);
print ("<br>");
var_dump($deptName);
print ("<br>");
print ("<br>");
echo "print_r prints human-readable information about a variable";
print ("<br>");
echo "var_dump dumps information about a variable ";
?>
</body>
</html>
