<?php
session_start();
$_SESSION['variable1'] = 10;
$_SESSION['variable2'] = 20;
?>